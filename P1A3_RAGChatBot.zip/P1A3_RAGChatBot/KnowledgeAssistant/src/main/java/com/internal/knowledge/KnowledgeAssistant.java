package com.internal.knowledge;

import com.internal.knowledge.citation.CitationEngine;
import com.internal.knowledge.context.ContextAssembler;
import com.internal.knowledge.fallback.FallbackHandler;
import com.internal.knowledge.feedback.FeedbackService;
import com.internal.knowledge.feedback.FeedbackSignal;
import com.internal.knowledge.format.ResponseFormatter;
import com.internal.knowledge.model.Chunk;
import com.internal.knowledge.model.ContextResult;
import com.internal.knowledge.model.FallbackResponse;
import com.internal.knowledge.model.LLMResponse;
import com.internal.knowledge.model.Query;
import com.internal.knowledge.prompt.SystemPrompt;
import com.internal.knowledge.query.QueryProcessor;
import com.internal.knowledge.store.InMemoryVectorStoreService;
import com.internal.knowledge.store.VectorStoreService;
import com.internal.knowledge.store.HashingEmbeddingService;

import java.time.LocalDateTime;
import java.util.List;

public class KnowledgeAssistant {
    private final QueryProcessor queryProcessor;
    private final ContextAssembler contextAssembler;
    private final FallbackHandler fallbackHandler;
    private final CitationEngine citationEngine;
    private final ResponseFormatter responseFormatter;
    private final VectorStoreService vectorStoreService;
    private final FeedbackService feedbackService;

    public KnowledgeAssistant() {
        this.queryProcessor = new QueryProcessor();
        this.contextAssembler = new ContextAssembler();
        this.fallbackHandler = new FallbackHandler();
        this.citationEngine = new CitationEngine();
        this.responseFormatter = new ResponseFormatter();
        this.feedbackService = new FeedbackService();
        this.vectorStoreService = new InMemoryVectorStoreService(new HashingEmbeddingService(), feedbackService);
        seedDocumentStore();
    }

    /**
     * Records user feedback (thumbs up/down) on a specific chunk that was
     * used in a response. Future searches will nudge that chunk's ranking
     * up or down based on accumulated feedback.
     */
    public void submitFeedback(String chunkId, FeedbackSignal signal) {
        feedbackService.recordFeedback(chunkId, signal);
    }

    public LLMResponse processQuery(Query query) {
        System.out.println("Processing query: " + query.getId());
        long startTime = System.currentTimeMillis();

        try {
            Query processedQuery = queryProcessor.process(query);

            List<Chunk> retrievedChunks = vectorStoreService.search(processedQuery.getText(), 5);

            FallbackResponse fallback = fallbackHandler.handleNoMatch(processedQuery, retrievedChunks);
            if (fallback != null) {
                System.out.println("Fallback triggered: " + fallback.getType());
                return LLMResponse.createFallback(fallback.getMessage(), fallback.getType(), fallback.getConfidence());
            }

            ContextResult context = contextAssembler.assembleContext(processedQuery, retrievedChunks);
            String prompt = SystemPrompt.buildContextPrompt(processedQuery, context);

            // Mock LLM response
            String mockResponse = generateMockResponse(processedQuery, context);
            LLMResponse llmResponse = LLMResponse.builder()
                .rawResponse(mockResponse)
                .formattedResponse(mockResponse)
                .confidenceScore(0.85)
                .isFallback(false)
                .build();

            LLMResponse finalResponse = citationEngine.processCitations(
                llmResponse.getRawResponse(), context);
            finalResponse.setConfidenceScore(0.85);
            finalResponse.setProcessingTimeMs(System.currentTimeMillis() - startTime);

            System.out.println("Query processing completed in " + finalResponse.getProcessingTimeMs() + "ms");
            return finalResponse;

        } catch (Exception e) {
            System.err.println("Error processing query: " + e.getMessage());
            return LLMResponse.createFallback(
                "An error occurred while processing your query. Please try again later.",
                "ERROR", 0.0);
        }
    }

    private void seedDocumentStore() {
        vectorStoreService.addChunk(Chunk.builder()
            .id("chunk1")
            .text("Service X deployment requires approval from the Change Management Board. The deployment window is between 2:00 AM and 4:00 AM UTC.")
            .source("Service X Deployment Runbook")
            .title("Production Deployments")
            .section("Deployment Process")
            .url("https://docs.internal/service-x/deploy/production")
            .similarityScore(0.89)
            .combinedScore(0.85)
            .createdAt(LocalDateTime.now().minusDays(5))
            .build());
        vectorStoreService.addChunk(Chunk.builder()
            .id("chunk2")
            .text("For Service X, ensure you have taken a backup of the current production database before any deployment.")
            .source("Database Operations Guide")
            .title("Pre-Deployment Steps")
            .section("Backup Procedures")
            .url("https://docs.internal/database/pre-deploy")
            .similarityScore(0.78)
            .combinedScore(0.72)
            .createdAt(LocalDateTime.now().minusDays(10))
            .build());
        vectorStoreService.addChunk(Chunk.builder()
            .id("chunk3")
            .text("Service X uses Blue-Green deployment strategy. The production environment is always behind the load balancer.")
            .source("Infrastructure Architecture")
            .title("Deployment Strategies")
            .section("Blue-Green Deployment")
            .url("https://docs.internal/infra/blue-green")
            .similarityScore(0.67)
            .combinedScore(0.62)
            .createdAt(LocalDateTime.now().minusDays(15))
            .build());
    }

    private String generateMockResponse(Query query, ContextResult context) {
        return "**Direct Answer:** Service X production deployment requires Change Management Board approval and must occur during the 2:00-4:00 AM UTC window [C1].\n\n" +
               "**Detailed Explanation:** Before initiating the deployment, you must take a backup of the current production database [C2]. The deployment itself uses a Blue-Green strategy where the production environment runs behind the load balancer [C3]. The Change Management Board approval must be obtained at least 24 hours in advance [C1].\n\n" +
               "**Additional Context:** The backup requirement is mandatory even if no database changes are planned [C2]. The 2:00-4:00 AM window is enforced to minimize business impact [C1].";
    }

    public static void main(String[] args) {
        System.out.println("=== Internal Knowledge Assistant ===");
        System.out.println("Starting up...\n");

        KnowledgeAssistant assistant = new KnowledgeAssistant();

        Query query = Query.builder()
            .id("Q-" + System.currentTimeMillis())
            .text("What is the process for deploying Service X in production?")
            .userId("user123")
            .department("Engineering")
            .timestamp(LocalDateTime.now())
            .build();

        System.out.println("Query: " + query.getText());
        System.out.println("--------------------------------------------------\n");

        LLMResponse response = assistant.processQuery(query);

        System.out.println("Response:\n");
        System.out.println(assistant.responseFormatter.formatForUI(response));

        System.out.println("\n--------------------------------------------------");
        System.out.println("Confidence: " + response.getConfidenceScore());
        System.out.println("Fallback: " + response.isFallback());
        System.out.println("Processing Time: " + response.getProcessingTimeMs() + "ms");

        // Simulate a user marking chunk1 as helpful - future searches will rank it slightly higher
        assistant.submitFeedback("chunk1", FeedbackSignal.POSITIVE);

        System.out.println("\n=== Done ===");
    }
}
